package com.zidanJmartKD.jmart_android.model;

/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import java.util.HashMap;

public class Serializable {
    public int id;
    private static HashMap<Class<?>, Integer> mapCounter = new HashMap<>();

}
