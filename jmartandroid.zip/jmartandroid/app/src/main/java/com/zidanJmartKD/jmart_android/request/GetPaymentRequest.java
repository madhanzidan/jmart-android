package com.zidanJmartKD.jmart_android.request;

import static com.zidanJmartKD.jmart_android.LoginActivity.getLoggedAccount;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

public class GetPaymentRequest extends StringRequest {
    private static final String URL = "http://10.0.2.2:8080/payment/page?page=0&pageSize=100";

    public GetPaymentRequest(Response.Listener<String> listener, @Nullable Response.ErrorListener errorListener) {
        super(Request.Method.GET, URL, listener, errorListener);
    }
}
