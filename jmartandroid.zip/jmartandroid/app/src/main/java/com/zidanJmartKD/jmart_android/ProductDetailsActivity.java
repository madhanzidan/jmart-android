package com.zidanJmartKD.jmart_android;
/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import static com.zidanJmartKD.jmart_android.LoginActivity.getLoggedAccount;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.zidanJmartKD.R;
import com.zidanJmartKD.jmart_android.request.CreateProductRequest;
import com.zidanJmartKD.jmart_android.request.PaymentRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ProductDetailsActivity extends AppCompatActivity {



    /**
     * Create page of Product Details Acivity
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        this.setTitle("Product Details");

        /**
         * Declare component of Product Details
         */
        TextView nameProduct = findViewById(R.id.nameProductDetail);
        TextView weightProduct = findViewById(R.id.weightProductDetail);
        TextView conditionProduct = findViewById(R.id.conditionProductDetail);
        TextView priceProduct = findViewById(R.id.priceProductDetail);
        TextView discountProduct = findViewById(R.id.discountProductDetail);
        TextView categoryProduct = findViewById(R.id.categoryProductDetail);
        TextView shipmentProduct = findViewById(R.id.shipmentPlansProductDetail);


        /**
         * Get intent from bundle in ProductsFragment
         */
        Bundle bundle = getIntent().getExtras();
        if(getIntent().getExtras() != null) {
            nameProduct.setText(bundle.getString("name"));
            weightProduct.setText(String.valueOf(bundle.getInt("weight")));

            /**
             * If conditional to convert condition used
             */
            if(String.valueOf(bundle.getBoolean("conditionUsed")).equals("false"))
                conditionProduct.setText("New");
            else
                conditionProduct.setText("Used");

            /**
             *  Use indonesian currency format for price
             */
            Locale indonesianLocale = new Locale("in", "ID");
            NumberFormat formatter = NumberFormat.getCurrencyInstance(indonesianLocale);
            priceProduct.setText(String.valueOf(formatter.format(bundle.getDouble("price"))));

            discountProduct.setText(String.valueOf(bundle.getDouble("discount")));
            categoryProduct.setText(bundle.getString("category"));

            /**
             *  If conditional to convert byte of Shipment Plans
             */
            if(String.valueOf(bundle.getByte("shipmentPlans")).equals("1"))
                shipmentProduct.setText("INSTANT");
            else if(String.valueOf(bundle.getByte("shipmentPlans")).equals("2"))
                shipmentProduct.setText("SAME DAY");
            else if(String.valueOf(bundle.getByte("shipmentPlans")).equals("3"))
                shipmentProduct.setText("NEXT DAY");
            else if(String.valueOf(bundle.getByte("shipmentPlans")).equals("4"))
                shipmentProduct.setText("REGULER");
            else if(String.valueOf(bundle.getByte("shipmentPlans")).equals("5"))
                shipmentProduct.setText("KARGO");
        }

        /**
         * Declaration components of Transaction Card
         */
        NumberPicker productAmount = findViewById(R.id.pickerProductAmount);
        productAmount.setMinValue(1);
        productAmount.setMaxValue(10);
        Button buyButton = findViewById(R.id.buyButtonProductDetails);
        CardView transactionCard = findViewById(R.id.transactionCard);
        Button confirmOrder = findViewById(R.id.buttonConfirmOrder);
        Button cancelOrder = findViewById(R.id.buttonCancelOrder);

        int productId = bundle.getInt("productId");
        int accountId = bundle.getInt("accountId");
        if(accountId == getLoggedAccount().id)
            buyButton.setVisibility(View.GONE);

        /**
         * Muncul card transaction ketika menekan button BUY
         */
        buyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buyButton.setVisibility(View.INVISIBLE);
                transactionCard.setVisibility(View.VISIBLE);
            }
        });
        cancelOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transactionCard.setVisibility(View.INVISIBLE);
                buyButton.setVisibility(View.VISIBLE);
            }
        });

        confirmOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int amountProduct = productAmount.getValue();
                int buyerId = getLoggedAccount().id;
                String shipmentAddress = getLoggedAccount().store.address;
                byte shipmentPlan = bundle.getByte("shipmentPlans");

                Response.Listener<String> listener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Double productPrice = bundle.getDouble("price");
                            Double discount = bundle.getDouble("discount");
                            Double discountedPrice = productPrice - (productPrice * discount/100);
                            Double finalTotal = discountedPrice * amountProduct;
                            JSONObject newObj = new JSONObject(response);
                            if (newObj != null){
                                Toast.makeText(ProductDetailsActivity.this, "Purchase success", Toast.LENGTH_SHORT).show();
                                getLoggedAccount().balance -= finalTotal;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(ProductDetailsActivity.this, "Sorry, purchase failed", Toast.LENGTH_SHORT).show();
                        }
                    }

                };

                Response.ErrorListener errorListener = new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ProductDetailsActivity.this, "Sorry, something went wrong", Toast.LENGTH_SHORT).show();
                    }
                };


                PaymentRequest paymentRequest = new PaymentRequest(buyerId, productId, amountProduct, shipmentAddress, shipmentPlan, listener, errorListener);
                RequestQueue queue = Volley.newRequestQueue(ProductDetailsActivity.this);
                queue.add(paymentRequest);
            }
        });


    }
}
