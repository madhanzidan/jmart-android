package com.zidanJmartKD.jmart_android.model;

import com.zidanJmartKD.jmart_android.LoginActivity;

import java.text.SimpleDateFormat;

public class ProductPayment {
    public Payment payment;
    public Product product;
    public Account account;


    public String toString(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return product.name +
                "\n" + "Buyer/Seller ID:" + payment.buyerId +
                "\n" + "Amount:" + payment.productCount +
                "\n" + dateFormat.format(payment.date);
    }
}
