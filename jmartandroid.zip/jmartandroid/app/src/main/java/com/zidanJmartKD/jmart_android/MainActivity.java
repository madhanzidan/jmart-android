package com.zidanJmartKD.jmart_android;
/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import static com.zidanJmartKD.jmart_android.LoginActivity.getLoggedAccount;
import static com.zidanJmartKD.jmart_android.ProductsFragment.productsReturned;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.zidanJmartKD.R;
import com.zidanJmartKD.jmart_android.model.Product;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    /**
     * Create menu item
     * @param menu
     * @return
     */
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //Apabila sebelum register store, add button akan invisible
        if(getLoggedAccount().store == null)
            menu.findItem(R.id.add_box).setVisible(false);
        else
            menu.findItem(R.id.add_box).setVisible(true);

        androidx.appcompat.widget.SearchView search = (androidx.appcompat.widget.SearchView) menu.findItem(R.id.search).getActionView();
        ArrayAdapter<Product> adapter = new ArrayAdapter<Product>(MainActivity.this, android.R.layout.simple_list_item_1, productsReturned);
        ListView listView = findViewById(R.id.listViewProducts);
        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                listView.setAdapter(adapter);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayAdapter<Product> adapter = new ArrayAdapter<Product>(MainActivity.this, android.R.layout.simple_list_item_1, productsReturned);
                listView.setAdapter(adapter);
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }

    private static final int NUM_PAGES = 2; //jumlah fragment pada MainActivity

    /**
     *   pager widget untuk melakukan swipe antar fragment
     */
    public static ViewPager2 viewPager;
    /**
     * Pager adapter untuk menampilkan pager widget pada fragment
     */
    private FragmentStateAdapter pagerAdapter;
    /**
     * Menentukan title pada fragment tab
     */
    private String[] titles = new String[]{"Products", "Filter"};

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("JMART");

        viewPager = findViewById(R.id.mypager);
        pagerAdapter = new MyPagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);

        //inflate layout dari tab
        TabLayout tabLayout =(TabLayout) findViewById(R.id.tab_layout);
        //Mendisplay tab
        new TabLayoutMediator(tabLayout, viewPager,(tab, position) -> tab.setText(titles[position])).attach();


        //Inisiasi component
        Button buttonApplyFilter = findViewById(R.id.buttonApplyFilter);
        Button buttonClearFilter = findViewById(R.id.buttonClearFilter);
        EditText inputNameFilter = findViewById(R.id.inputNameFilter);
        EditText inputLowestPriceFilter = findViewById(R.id.inputLowestPriceFilter);
        EditText inputHighestPriceFilter = findViewById(R.id.inputHighestPriceFilter);
        CheckBox checkBoxNewFilter = findViewById(R.id.checkBoxNewFilter);
        CheckBox checkBoxUsedFilter = findViewById(R.id.checkBoxUsedFilter);
        Spinner spinnerFilter = findViewById(R.id.spinnerFilter);
    }

    private class MyPagerAdapter extends FragmentStateAdapter {
        public MyPagerAdapter(FragmentActivity fragmentActivity){
            super(fragmentActivity);
        }

        @Override
        public Fragment createFragment (int pos) {
            switch (pos) {
                case 0:
                    return ProductsFragment.newInstance("Products Fragment");
                case 1:
                    return FilterFragment.newInstance("Filter Fragment");
                default:
                    return ProductsFragment.newInstance("Products Fragment, Default");
            }
        }

        @Override
        public int getItemCount() {
            return NUM_PAGES;
        }
    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() == 0)
            super.onBackPressed();
        else
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
    }

    /**
     * Create intent on menu
     * @param item
     * @return intent for change activity
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.add_box:
                Intent toCreateProductPage = new Intent(MainActivity.this, CreateProductActivity.class);
                startActivity(toCreateProductPage);
                return true;
            case R.id.person:
                Intent toAboutMePage = new Intent(MainActivity.this, AboutMeActivity.class);
                startActivity(toAboutMePage);
                return true;
            case R.id.invoice:
                Intent toInvoicePage = new Intent(MainActivity.this, InvoiceActivity.class);
                startActivity(toInvoicePage);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}