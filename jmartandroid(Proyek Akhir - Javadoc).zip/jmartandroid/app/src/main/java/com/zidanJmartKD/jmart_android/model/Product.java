package com.zidanJmartKD.jmart_android.model;

/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

public class Product extends Serializable {
    public int accountId;
    public ProductCategory category;
    public boolean conditionUsed;
    public double discount;
    public String name;
    public double price;
    public byte shipmentPlans;
    public int weight;

    /**
     * Shows product name to list view on product fragment
     * @return name of product
     */
    public String toString(){
      return name;
    }
}
