package com.zidanJmartKD.jmart_android.request;

/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

public class AccountRequest extends RequestFactory {
    /**
     * Declare URL to get account
     */
    private static final String REGISTER_STORE = "/registerStore?name=%s&address=%s&phoneNumber=%s";
    private static final String TOP_UP="/topUp?balance=%f";
    private static final String parentURI = "account";

    /**
     * Create string request for store registration
     * @param parentURI
     * @param id
     * @param name
     * @param address
     * @param phoneNumber
     * @param listener
     * @param errorListener
     * @return string request with url after concat
     */
    public static StringRequest registerStore (
            String parentURI,
            int id,
            String name,
            String address,
            String phoneNumber,
            Response.Listener<String> listener,
            Response.ErrorListener errorListener
    ){
        String url = String.format(getURL(), parentURI, id);
        url = url.concat(REGISTER_STORE);
        url = String.format(url, name, address, phoneNumber);
        return new StringRequest(Request.Method.POST, url, listener, errorListener);
    }

    /**
     * String Request to top up the balance
     * @param id
     * @param balance
     * @param listener
     * @param errorListener
     * @return StringRequest with url after concat
     */
    public static StringRequest topUp (
            int id,
            double balance,
            Response.Listener<String> listener,
            Response.ErrorListener errorListener
    ){
        String url = String.format(getURL(), parentURI, id);
        url = url.concat(TOP_UP);
        url = String.format(url, balance);
        return new StringRequest(Request.Method.POST, url, listener, errorListener);
    }
}
