package com.zidanJmartKD.jmart_android;

/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import android.content.Intent;
import android.os.Bundle;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.gson.Gson;
//import com.zidanJmartKD.jmart_android.databinding.ActivityAccountInvoiceBinding;

import com.zidanJmartKD.R;
import com.zidanJmartKD.jmart_android.model.Payment;
import com.zidanJmartKD.jmart_android.model.Product;
import com.zidanJmartKD.jmart_android.model.ProductPayment;
import com.zidanJmartKD.jmart_android.request.GetPaymentRequest;
import com.zidanJmartKD.jmart_android.request.GetProductRequest;
import com.zidanJmartKD.jmart_android.request.PaymentRequest;
import com.zidanJmartKD.jmart_android.request.RequestFactory;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AccountInvoiceFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public List<ProductPayment> paymentsReturned = new ArrayList<>();

    public AccountInvoiceFragment() {} //Empty constructor sebagai syarat

    /**
     * Get the account invoice fragment
     * @param param1
     * @return Fragment that shows transaction invoice for account
     */
    public static AccountInvoiceFragment newInstance(String param1) {
        AccountInvoiceFragment accountInvoiceFragment = new AccountInvoiceFragment();
        Bundle b = new Bundle();
        b.putString(ARG_PARAM1, param1);
        accountInvoiceFragment.setArguments(b);
        return accountInvoiceFragment;
    }

    /**
     * Create the parameter on fragment
     * @param savedInstanceState
     */
    @Override
    public void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    /**
     * Create the fragment tab of Store Invoice
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return view of Account Invoice Tab
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_account_invoice, container, false);
        ListView listAccountInvoice = v.findViewById(R.id.listViewFragmentAccountInvoice);
        Gson gson = new Gson();
        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    /**
                     * Get the transaction data
                     */
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        Payment payment = gson.fromJson(obj.toString(), Payment.class);
                        ProductPayment productPayment = new ProductPayment();
                        productPayment.payment = payment;

                        Response.Listener<String> listener1 = new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject newObj = new JSONObject(response);
                                    Product product = gson.fromJson(newObj.toString(), Product.class);
                                    productPayment.product = product;
                                    if(productPayment.payment.buyerId == LoginActivity.getLoggedAccount().id)
                                    {
                                        productPayment.account = LoginActivity.getLoggedAccount();
                                        paymentsReturned.add(productPayment);
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                /**
                                 * Create adapter to convert to listView
                                 */
                                ArrayAdapter<ProductPayment> allItemsAdapter = new ArrayAdapter<ProductPayment>(getActivity().getBaseContext(), android.R.layout.simple_list_item_1, paymentsReturned);
                                listAccountInvoice.setAdapter(allItemsAdapter);
                            }
                        };
                        Response.ErrorListener errorListener = new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(getContext(), "Sorry, something went wrong", Toast.LENGTH_SHORT).show();
                            }
                        };
                        /**
                         * Create StringRequest to get the transaction data
                         */
                        StringRequest getProductPayment = RequestFactory.getById
                                ("product",
                                        productPayment.payment.productId,
                                        listener1,
                                        errorListener
                                );
                        RequestQueue queue = Volley.newRequestQueue(getActivity().getBaseContext());
                        queue.add(getProductPayment);
                    }
                }catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "Sorry, something went wrong", Toast.LENGTH_SHORT).show();
            }
        };

        /**
         * Pass the data using GetPaymentRequest
         */
        int pages = 0;
        GetPaymentRequest newGetAccountInvoice = new GetPaymentRequest(listener, errorListener);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getBaseContext());
        queue.add(newGetAccountInvoice);
        return v;

    }

}