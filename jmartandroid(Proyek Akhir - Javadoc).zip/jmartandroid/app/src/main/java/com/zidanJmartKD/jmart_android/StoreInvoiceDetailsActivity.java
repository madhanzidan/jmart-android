package com.zidanJmartKD.jmart_android;

/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.zidanJmartKD.R;

public class StoreInvoiceDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_invoice_details);
        this.setTitle("Invoice Details");
    }
}