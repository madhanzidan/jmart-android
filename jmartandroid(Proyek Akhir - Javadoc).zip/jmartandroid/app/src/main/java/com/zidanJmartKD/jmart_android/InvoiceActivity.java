package com.zidanJmartKD.jmart_android;

import static com.zidanJmartKD.jmart_android.MainActivity.viewPager;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
//import com.zidanJmartKD.jmart_android.databinding.ActivityInvoiceBinding;

import com.zidanJmartKD.R;

public class InvoiceActivity extends AppCompatActivity {

    private static final int NUM_PAGES = 2; //jumlah fragment pada MainActivity

    /**
     *   pager widger untuk melakukan swipe antar fragment
     */
    public static ViewPager2 viewPager_invoice;
    /**
     * Pager adapter untuk menampilkan pager widget pada fragment
     */
    private FragmentStateAdapter pagerAdapter;
    /**
     * Menentukan title pada fragment tab
     */
    private String[] titles = new String[]{"Account", "Store"};

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);
        this.setTitle("Invoice");

        viewPager_invoice = findViewById(R.id.mypager_invoice);
        pagerAdapter = new MyPagerAdapter(this);
        viewPager_invoice.setAdapter(pagerAdapter);

        //inflate layout dari tab
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout_invoice);
        //Mendisplay tab
        new TabLayoutMediator(tabLayout, viewPager_invoice, (tab, position) -> tab.setText(titles[position])).attach();
    }


    private class MyPagerAdapter extends FragmentStateAdapter {
        public MyPagerAdapter(FragmentActivity fragmentActivity){
            super(fragmentActivity);
        }

        @Override
        public Fragment createFragment (int pos) {
            switch (pos) {
                case 0:
                    return AccountInvoiceFragment.newInstance("Account Invoice Fragment");
                case 1:
                    return StoreInvoiceFragment.newInstance("Store Invoice Fragment");
                default:
                    return AccountInvoiceFragment.newInstance("Account Invoice Fragment, Default");
            }
        }

        @Override
        public int getItemCount() {
            return NUM_PAGES;
        }
    }

    @Override
    public void onBackPressed() {
        if (viewPager_invoice.getCurrentItem() == 0)
            super.onBackPressed();
        else
            viewPager_invoice.setCurrentItem(viewPager_invoice.getCurrentItem() - 1);
    }

}