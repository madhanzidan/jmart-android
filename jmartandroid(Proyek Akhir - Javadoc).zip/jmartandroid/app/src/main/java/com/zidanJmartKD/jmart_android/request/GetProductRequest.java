package com.zidanJmartKD.jmart_android.request;

/**
 * @author Zidan Ramadhan
 * @author zidan.ramadhan@ui.ac.id
 * @version 1.0
 */

import static com.zidanJmartKD.jmart_android.LoginActivity.getLoggedAccount;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class GetProductRequest extends StringRequest {
    private static final String URL = "http://10.0.2.2:8080/product/" + getLoggedAccount().id + "/store?page=%d&pageSize=%d";

    /**
     * Request to get product to show in the list view
     * @param page
     * @param listener
     * @param errorListener
     */
    public GetProductRequest(Integer page, Response.Listener<String> listener, @Nullable Response.ErrorListener errorListener) {
        super(Request.Method.GET, String.format(URL, page, 10), listener, errorListener);
    }
}
